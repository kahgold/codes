# ifndef TADFILA_H
# define TADFILA_H

#include "tad_fila_lab.cpp"

class TadFila{
    private:
        int numeros[10];
        int inicio;
        int fim;
        int qtd;
    public:
        TadFila();
        bool inserir(int n);
        int extrair();
        int localizar(int n);
        int quantidade();
        void imprimir();
        bool cheia();
        bool vazia();
};
# endif