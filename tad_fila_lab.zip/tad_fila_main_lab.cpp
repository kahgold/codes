#include "tad_fila_lab.cpp"
#include "tad_fila_lab.h"
#include <iostream>

using namespace std;

main(){
    int tamanho;
    cout << "Por favor informar o tamanho da fila: "; cin >> tamanho;
    Tadfila tf(tamanho);

    while(true){
        cout << "\n Programa para testar vetor";
        cout << "\n ------------------------\n";
        cout << "\n 0 -> encerrar o programa";
        cout << "\n 1 -> inserir na fila";
        cout << "\n 2 -> extrair da fila";
        cout << "\n 3 -> localizar na fila";
	    cout << "\n 4 -> quantidade de elementos";
        cout << "\n 5 -> imprimir a fila";

        int opc;
        cout << "Escolha uma opção: "; cin >> opc;

        if(opc == 0){
            break
        }

        else if(opc == 1){
            tf.inserir(int n);
        }

        else if(opc == 2){
            tf.extrair()
        }

        else if(opc == 3){
            tf.localizar(int n);
        }

        else if(opc == 4){
            tf.quantidade();
        }

        else if(opc == 5){
            tf.imprirmir()
        }